package uk.ac.sheffield.assignment2021;

import uk.ac.sheffield.assignment2021.codeprovided.AbstractQueryParser;
import uk.ac.sheffield.assignment2021.codeprovided.Query;
import uk.ac.sheffield.assignment2021.codeprovided.SubQuery;
import uk.ac.sheffield.assignment2021.codeprovided.WineProperty;
import uk.ac.sheffield.assignment2021.codeprovided.WineType;

import java.util.ArrayList;
import java.util.List;

public class QueryParser extends AbstractQueryParser {
    @Override
    public List<Query> readQueries(List<String> queryTokens) throws IllegalArgumentException {
    	//creating a copy of queryTokens
    	List<String> queriesTokens = new ArrayList<>();
    	queriesTokens.addAll(queryTokens);
    	//List of queries to be returned 
    	List<Query> queries = new ArrayList<>();

    	/*main for loop, loops through all queryTokens Strings and enter inner loops whenever it finds "select" 
    	/*hence: indicating new query, then from there it will enter one of three sub loops depending on the wine type
    	because it's the easiest property to detect*/
    	
    	for (int i=0; i<queriesTokens.size(); i++) {
    		if (queriesTokens.get(i).equals("select") ) {
    			//First case loop:  when after "select" by two indexes there is "or" meaning the wine type should be ALL
    			if (queriesTokens.get(i+2).equals("or")) {
    				//list to store this query subqueries
					List<SubQuery> sl = new ArrayList<SubQuery>();
					// i+4 because the index of "where" would be the fifth in type ALL 
						for (int j=i+4; j<queriesTokens.size(); j++) {
							//to make sure not going through next query's subqueries we should stop at the next "select"
							if (!queriesTokens.get(j).equals("select")) {
							 if (queriesTokens.get(j).equals("where" ) || queriesTokens.get(j).equals("and") ) {
	    						WineProperty p = WineProperty.fromFileIdentifier(queriesTokens.get(j+1));
	    						String opr = queriesTokens.get(j+2);
	    						double val = 	Double.parseDouble(queriesTokens.get(j+3));
	    						sl.add(new SubQuery(p,opr,val));
							 }
							}else break;
						}
					//creating this query and updating final list of queries
					Query q = new Query(sl, WineType.ALL);
					queries.add(q);
					
				}
	    		//second case: when after "select" there is "red"
				else if (queriesTokens.get(i+1).equals("red")) {
					//list to store this query subqueries
					List<SubQuery> sl = new ArrayList<SubQuery>();
					// i+2 because the index of "where" would be the third in type RED
						for (int j=i+2; j<queriesTokens.size(); j++) {
							//to make sure not going through next query's subqueries we should stop at the next "select"
							if (!queriesTokens.get(j).equals("select")) {
							 if (queriesTokens.get(j).equals("where" ) || queriesTokens.get(j).equals("and") ) {
	    						WineProperty p = WineProperty.fromFileIdentifier(queriesTokens.get(j+1));
	    						String opr = queriesTokens.get(j+2);
	    						double val = 	Double.parseDouble(queriesTokens.get(j+3));
	    						sl.add(new SubQuery(p,opr,val));
							 }
							}else break;
						} 
					//creating this query and updating final list of queries
					Query q = new Query(sl, WineType.RED);
					queries.add(q);	 
				}
    			//third case: when after "select" there is "white"
				else if (queriesTokens.get(i+1).equals("white")) {
					//list to store this query subqueries
					List<SubQuery> sl = new ArrayList<SubQuery>();
					// i+2 because the index of "where" would be the third in type WHITE
						for (int j=i+2; j<queriesTokens.size(); j++) {
							//to make sure not going through next query's subqueries we should stop at the next "select"
							if (!queriesTokens.get(j).equals("select")) {
							 if (queriesTokens.get(j).equals("where" ) || queriesTokens.get(j).equals("and") ) {
			    				WineProperty p = WineProperty.fromFileIdentifier(queriesTokens.get(j+1));
	    						String opr = queriesTokens.get(j+2);
	    						double val = 	Double.parseDouble(queriesTokens.get(j+3));
	    						sl.add(new SubQuery(p,opr,val));
	    						
							 } 
							}else break;
						}
					//creating this query and updating final list of queries
					Query q = new Query(sl, WineType.WHITE);
					queries.add(q);
				}	
    		} 
    		
    	}
    	
		return queries;
    }
}
