package uk.ac.sheffield.assignment2021.gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.util.Map;

import uk.ac.sheffield.assignment2021.codeprovided.gui.AbstractHistogram;
import uk.ac.sheffield.assignment2021.codeprovided.gui.AbstractHistogramPanel;
import uk.ac.sheffield.assignment2021.codeprovided.gui.AbstractWineSampleBrowserPanel;
import uk.ac.sheffield.assignment2021.codeprovided.gui.HistogramBin;

public class HistogramPanel extends AbstractHistogramPanel
{
    public HistogramPanel(AbstractWineSampleBrowserPanel parentPanel, AbstractHistogram histogram)
    {
        super(parentPanel, histogram);
    }

    /* NOTE: your HistogramPanel must override JPanel's `protected void paintComponent(Graphics g)`,
    in order to redraw your Histogram whenever it is updated.
    For example:*/

    //the histogram plotting does not work, sorry to disappoint , haven't been my best month 
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawXaxes(g);
        drawYaxes(g);
        drawBins(g);
    }
    
    
    void drawXaxes(Graphics g) {
    	Dimension d = getSize();
        Graphics2D g2 = (Graphics2D) g;
        Stroke stroke = new BasicStroke(4f);
        Line2D xAxes = new Line2D.Double(
                0,
                d.height,
                d.width,
                d.height
        );
        g2.setStroke(stroke);
        g2.draw(xAxes);
    }
    
    void drawYaxes(Graphics g) {
    	Dimension d = getSize();
        Graphics2D g2 = (Graphics2D) g;
        Stroke stroke = new BasicStroke(4f);
        Line2D yAxes = new Line2D.Double(
            0,
            0,
            0,
            d.height
        );
        g2.setColor(Color.black);
        g2.setStroke(stroke); 
        g2.draw(yAxes);
    }
    
    void drawBins(Graphics g) {
    	Dimension d = getSize();
    	Graphics2D g2 = (Graphics2D) g;
    	Map<HistogramBin, Integer> wineCountsPerBin = this.getHistogram().getWineCountsPerBin();
    	for (Map.Entry<HistogramBin, Integer> entry : wineCountsPerBin.entrySet()) {
            HistogramBin bin = entry.getKey();
            int numWine = entry.getValue();
            if (numWine != 0) {
            	 int width = (int) bin.getUpperBoundary()- (int)bin.getLowerBoundary();
            int hieght = (int) d.height - numWine;
            int x =(int) bin.getLowerBoundary();
            int y = d.height;
            g2.setColor(Color.black);
            g2.fillRect(x, y, width, hieght);
            }
           
        }
    }
    

     
}
