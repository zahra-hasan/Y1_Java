package uk.ac.sheffield.assignment2021;

import uk.ac.sheffield.assignment2021.codeprovided.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

public class WineSampleCellar extends AbstractWineSampleCellar {
    /**
     * Constructor - reads wine sample datasets and list of queries from text file,
     * and initialises the wineSampleRacks Map
     *
     * @param redWineFilename
     * @param whiteWineFilename
     */
    public WineSampleCellar(String redWineFilename, String whiteWineFilename) {
        super(redWineFilename, whiteWineFilename);
    }

    @Override
    public WinePropertyMap parseWineFileLine(String line) throws IllegalArgumentException {
    	//Splitting the line provided into a String Array
        String split = ";";
        
        String[] valuesStringArray = line.split(split); 
        //throws IllegalArgumentException if the properties values are less than 12 (fixed properties number)
        if (valuesStringArray.length != 12) {
        	throw new IllegalArgumentException("File format is incorrect; must includes values for every property");
        }
        //Converting the String Array to a Double Array
        double[] valuesDoubleArray = new double[valuesStringArray.length];
        for (int i=0; i<valuesDoubleArray.length; i++) {
        	valuesDoubleArray[i] = Double.parseDouble(valuesStringArray[i]);
        } 
        WinePropertyMap winePropertyMap = new WinePropertyMap();
        //pairing properties and their values by looping through WineProperty Enum and values Array
        for ( int i=0; i<valuesDoubleArray.length; i++) {
        	winePropertyMap.put(WineProperty.values()[i], valuesDoubleArray[i]);
        }return winePropertyMap;
    }

    @Override
    public void updateCellar() {
    	//new List to store ALL wine types
    	List<WineSample> wineList = new ArrayList<>();
    	//Extracting the wines list 
    	wineList.addAll(getWineSampleList(WineType.RED));
    	wineList.addAll(getWineSampleList(WineType.WHITE));
    	//updating the wineSampleRacks to have am additional list with all wine types
        wineSampleRacks.put(WineType.ALL, wineList);
    }

    @Override
    public double getMinimumValue(WineProperty wineProperty, List<WineSample> wineList)
            throws NoSuchElementException {
    	if (wineList.size()==0 || wineList == null) {
    		throw new NoSuchElementException("List provided is not valid, must have one double value at least");
    	}
    	List<Double> propertiesValues = new ArrayList<>();
        for (WineSample p : wineList) {
        	propertiesValues.add(p.getProperty(wineProperty));
        }
        double minValue = Collections.min(propertiesValues);
        return minValue;
    }

    @Override
    public double getMaximumValue(WineProperty wineProperty, List<WineSample> wineList)
    		 throws NoSuchElementException {
    	if (wineList.size()==0 || wineList == null) {
    		throw new NoSuchElementException("List provided is not valid, must have one double value at least");
    	}
    	List<Double> propertiesValues = new ArrayList<>();
        for (WineSample p : wineList) {
        	propertiesValues.add(p.getProperty(wineProperty));
        }
        double maxValue = Collections.max(propertiesValues);
        return maxValue;
    }

    @Override
    public double getMeanAverageValue(WineProperty wineProperty, List<WineSample> wineList)
    		 throws NoSuchElementException {
    	if (wineList.size()==0 || wineList == null) {
    		throw new NoSuchElementException("List provided is not valid, must have one double value at least");
    	}
    	List<Double> propertiesValues = new ArrayList<>();
        for (WineSample p : wineList) {
        	propertiesValues.add(p.getProperty(wineProperty));
        }
        //calculating average using for loop
        double total = 0;
        for (double val : propertiesValues) {
        	total += val;
        }
        double avg = total/propertiesValues.size();
        double rounded = Math.round(avg*1000.0)/1000.0;
        return rounded;
    }

    @Override
    public List<WineSample> getFirstFiveWines(WineType type) {
    	//Empty List to store first five wines
        List<WineSample> firstFiveList = new ArrayList<>();
        //Check that the type provided is not ALL
        if (type != WineType.ALL) {
        	//loops through first five elements only
        	for (int i=0; i<5; i++) {
        		firstFiveList.add(getWineSampleList(type).get(i));
        	}
        }
        return firstFiveList;
    }
}
