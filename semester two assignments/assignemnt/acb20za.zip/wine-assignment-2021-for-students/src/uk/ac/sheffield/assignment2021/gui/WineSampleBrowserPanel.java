package uk.ac.sheffield.assignment2021.gui;


import java.util.ArrayList;

import java.util.List;

import javax.swing.JTextArea;

import uk.ac.sheffield.assignment2021.codeprovided.AbstractWineSampleCellar;
import uk.ac.sheffield.assignment2021.codeprovided.Query;
import uk.ac.sheffield.assignment2021.codeprovided.SubQuery;
import uk.ac.sheffield.assignment2021.codeprovided.WineProperty;
import uk.ac.sheffield.assignment2021.codeprovided.WineSample;
import uk.ac.sheffield.assignment2021.codeprovided.WineType;
import uk.ac.sheffield.assignment2021.codeprovided.gui.AbstractWineSampleBrowserPanel;

public class WineSampleBrowserPanel extends AbstractWineSampleBrowserPanel{
    public WineSampleBrowserPanel(AbstractWineSampleCellar cellar) {
        super(cellar);
    }

    @Override
    public void addListeners() {
    	//Choose to use lambda expressions as it is easier and more neat
        buttonAddFilter.addActionListener(e -> {
        	addFilter();
        	}
        );
        buttonClearFilters.addActionListener(e ->{
        	clearFilters();
        	}
        );
        comboWineTypes.addActionListener(e ->{
        	executeQuery(); // because it needs to update wine type with each execution 
        	//wine samples and statics will depend on the wine type selected as well as the histogram
        	updateWineDetailsBox();
        	updateStatistics();
        	updateHistogram();
    		}
        );
    
    }

    @Override
    public void addFilter() {
    	clearTextArea(subQueriesTextArea);
    	if (value.getText().isEmpty()) {
    		subQueriesTextArea.append("please provide a value");
    	}
    	//the main functionality of the button
    	else {
	    	//getting this subQuery wine property first	
	    	WineProperty wineProperty = WineProperty.fromName((String)comboQueryProperties.getSelectedItem());
	    	//make sure no property is selected twice with different operators or values 
	    	List<WineProperty> propertiesToCheck = new ArrayList<WineProperty>();
	    	for (SubQuery sub: subQueryList) {
	    		propertiesToCheck.add(sub.getWineProperty());
	    	}
	    	//case if the wine property was not selected before
	    	if (!propertiesToCheck.contains(wineProperty)) {
	    		String operator = (String) comboOperators.getSelectedItem();
	    		double val = Double.parseDouble(value.getText());
	    		SubQuery toAdd = new SubQuery(wineProperty, operator, val);
	    		subQueryList.add(toAdd);
	    	}
	    	//case if the wine property was selected once before, it will be replaced with the new arguments for value and operator
	    	//this is to avoid subQueries that does not make sense eg. qual > 9 && qual <9 applied to filter
	    	else if (propertiesToCheck.contains(wineProperty)) {
	    		for (SubQuery sub: subQueryList) {
		    		if (sub.getWineProperty().equals(wineProperty)) {
		    			int subToChange = subQueryList.indexOf(sub);
		    			String operator = (String) comboOperators.getSelectedItem();
			    		double val = Double.parseDouble(value.getText());
			    		SubQuery toAdd = new SubQuery(wineProperty, operator, val);
			    		subQueryList.set(subToChange, toAdd);
		    		}
		    	}
	    	}
	    	//FINALLY appending the sub queries to the text area 
	    	for (SubQuery sub: subQueryList) {
	    		subQueriesTextArea.append(sub.toString()+", ");
	    	}
	    	//those are inside addFilter() method because they should not be executed if there is no complete sub query
	    	executeQuery();
	        updateWineDetailsBox();
	        updateStatistics();
	        updateHistogram();
	    }
    }

    @Override
    public void clearFilters() {
    	subQueryList.clear();
    	clearTextArea(subQueriesTextArea);
    	clearTextArea(filteredWineSamplesTextArea);
    	clearTextArea(statisticsTextArea);
    	updateHistogram();
    }

    @Override
    public void updateStatistics() {
    	//clear Text Area and start writing again
    	clearTextArea(statisticsTextArea);
    	//creating a list of all wine properties need to be displayed, extracted from subQueryList
        List<WineProperty> winePropertyList = new ArrayList<WineProperty>();
        for (SubQuery sub: subQueryList) {
        		winePropertyList.add(sub.getWineProperty());
        }
        //calculating min/max/avg for each property using selected wine type and appending to staticTextArea
        WineType wineType = WineType.valueOf((String)comboWineTypes.getSelectedItem());
      //check if there are wine samples
        if (!(filteredWineSampleList.size() == 0 )) {
        	for (WineProperty p : winePropertyList) {
        	double max = cellar.getMaximumValue(p, cellar.getWineSampleList(wineType));
        	double min = cellar.getMinimumValue(p, cellar.getWineSampleList(wineType));
        	double avg = cellar.getMeanAverageValue(p, cellar.getWineSampleList(wineType));
        	String toAdd = "Wine property: " + p.getName()+ " max value: " + String.valueOf(max) +
        			", min value: "+ String.valueOf(min) + ", avrage value: " + String.valueOf(avg);
        	statisticsTextArea.append(toAdd+"\n");
        	}
        	int total = cellar.getNumberWineSamples(wineType);
        	int displayed = filteredWineSampleList.size();
        	statisticsTextArea.append("Number of wine samples displayed is = "+ displayed +
        			" out of " + total + " wine samples of the same type.");
        }
        else {statisticsTextArea.append("no matches found");}
        
        
    }

    @Override
    public void updateWineDetailsBox() {
    	//clear Text Area and start writing again
    	clearTextArea(filteredWineSamplesTextArea);
    	//check if there are wine samples
    	if (!(filteredWineSampleList.size() == 0 )) {
    		for (WineSample w : filteredWineSampleList ) {
    			filteredWineSamplesTextArea.append(w.toString()+"\n");
    		}
    	}
    	else {filteredWineSamplesTextArea.append("no matches found");}
    }

    @Override
    public void executeQuery() {
    	//this is to make sure that all wine samples should be displayed if there are non sub queries
    	if (!subQueryList.isEmpty()) { 
    	Query q = new Query(subQueryList,WineType.valueOf((String)comboWineTypes.getSelectedItem()));
    	 filteredWineSampleList = q.executeQuery(cellar);
    	}
    	else {
    		WineType wineType = WineType.valueOf((String)comboWineTypes.getSelectedItem());
    		filteredWineSampleList = cellar.getWineSampleList(wineType);
    	}
    	
    }
  
    //helper method to clear text areas
    public void clearTextArea(JTextArea textArea) {
    	textArea.selectAll();
    	textArea.replaceSelection("");
    }
    
}
