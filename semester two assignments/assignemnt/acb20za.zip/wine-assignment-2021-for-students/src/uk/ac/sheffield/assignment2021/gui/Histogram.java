package uk.ac.sheffield.assignment2021.gui;

import uk.ac.sheffield.assignment2021.codeprovided.AbstractWineSampleCellar;
import uk.ac.sheffield.assignment2021.codeprovided.WineProperty;
import uk.ac.sheffield.assignment2021.codeprovided.WineSample;
import uk.ac.sheffield.assignment2021.codeprovided.gui.AbstractHistogram;
import uk.ac.sheffield.assignment2021.codeprovided.gui.HistogramBin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

public class Histogram extends AbstractHistogram {
    /**
     * Constructor. Called by AbstractWineSampleBrowserPanel
     *
     * @param cellar              to allow for getting min / max / avg values
     * @param filteredWineSamples a List of WineSamples to generate a histogram for.
     *                            These have already been filtered by the GUI's queries.
     * @param property            the WineProperty to generate a histogram for.
     */
    public Histogram(AbstractWineSampleCellar cellar, List<WineSample> filteredWineSamples, WineProperty property)
    {
        super(cellar, filteredWineSamples, property);
    }

    @Override
    public void updateHistogramContents(WineProperty property, List<WineSample> filteredWineSamples) {
    	//getting all the relevant values for the selected property
    	List<Double> values = new ArrayList<Double>();
    	if (filteredWineSamples.size() !=0) {
    		for (WineSample w : filteredWineSamples) {
    			double val = w.getProperty(property);
    			values.add(val);
    		}
	        Collections.sort(values);
	        //calculating lowest and highest values of the property selected 
	        int lowestValue = (int) Math.round(values.get(0));
	        int highestValue = (int) Math.round(values.get(values.size()-1));
	        //calculate the intervals then number of bins accordingly 
	        double interval=0;
	        int numBins = 0;
	        if (highestValue != lowestValue) {
	        	interval = NUMBER_BINS/(highestValue-lowestValue);
	        	numBins = (int) Math.round(highestValue/interval);
	        }
	        else if (highestValue == lowestValue) {
	        	interval =0;
	        	numBins=1;
	        }
	        //create new arrayList to store the bins
	        List<HistogramBin> histograms = new ArrayList<HistogramBin>(numBins);
	        //create first bin and add it
	        HistogramBin firsHistogram = new HistogramBin(lowestValue, lowestValue+interval , false);
	        histograms.add(firsHistogram);
	        //now we have first histogram we will make use of it's upper boundary to start a loop creating the rest of bins
	        double lowerBoundary = firsHistogram.getUpperBoundary();
	        for (int i=0; i<numBins; i++) {
	        	if  (i != numBins-1) {
	        		histograms.add(new HistogramBin(lowerBoundary, lowerBoundary+interval, false));
	        		lowerBoundary = lowerBoundary+interval;
	        	}
	        	else {
	        		histograms.add(new HistogramBin(lowerBoundary, lowerBoundary+interval, true));
	        	}	
	        }
	        //now we have the bins ready to be used we should check how many wine are actually in every one 
	        //then add the key-value pairs to the map
	        int numWineInBin = 0;
	        for (HistogramBin bin : histograms) {
	        	for (double val : values) {
	        		if (bin.valueInBin(val)) {
	        			numWineInBin++;
	        		}
	        	}
	        	wineCountsPerBin.put(bin, numWineInBin);
	        	//reset wine number to zero for the next bin
	        	numWineInBin =0; 
	        }  
    	}
    }

    @Override
    public double getAveragePropertyValue() throws NoSuchElementException {
    	double avg = cellar.getMeanAverageValue(property, filteredWineSamples);
        return avg;
    }
}

