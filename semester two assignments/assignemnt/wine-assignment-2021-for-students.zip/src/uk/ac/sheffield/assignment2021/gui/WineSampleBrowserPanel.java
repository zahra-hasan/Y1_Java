package uk.ac.sheffield.assignment2021.gui;

import uk.ac.sheffield.assignment2021.codeprovided.AbstractWineSampleCellar;
import uk.ac.sheffield.assignment2021.codeprovided.gui.AbstractWineSampleBrowserPanel;

public class WineSampleBrowserPanel extends AbstractWineSampleBrowserPanel {
    public WineSampleBrowserPanel(AbstractWineSampleCellar cellar) {
        super(cellar);
    }

    @Override
    public void addListeners() {
        // TODO implement
    }

    @Override
    public void addFilter() {
        // TODO implement
    }

    @Override
    public void clearFilters() {
        // TODO implement
    }

    @Override
    public void updateStatistics() {
        // TODO implement
    }

    @Override
    public void updateWineDetailsBox() {
        // TODO implement
    }

    @Override
    public void executeQuery() {
        // TODO implement
    }
}
