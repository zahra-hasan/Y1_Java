/** 
* MeasurementGenerator.java
* 
* Copyright (c) University of Sheffield, 2021
* 
* @version 1.3 11/01/2021
* 
* @author Maria-Cruz Villa-Uriol
* @author Ben Clegg
*/

package uk.ac.sheffield.com1003.problemsheet1;

import uk.ac.sheffield.com1003.problemsheet1.Distance.DistanceUnit;

public class MeasurementGenerator {
	
	
	public static void main(String[] args) {
		
		//instances 
		Steps stepsMike = new Steps(5490);
		HeartRate heartRateMike = new HeartRate(98);
		Distance distanceMike = new Distance(4.3 , DistanceUnit.KILOMETRES);
		
		Steps stepsEddy = new Steps(0);
		stepsEddy.setValue(7033);
		HeartRate heartRateEddy = new HeartRate(0);
		heartRateEddy.setValue(121);
		Distance distanceEddy = new Distance(0);
		distanceEddy.setValue(3.4);
		
		Distance distanceZahra = new Distance(4.4 , DistanceUnit.MILES);
		
		//Displaying on console
		System.out.println("Mike's statistics: ");
		System.out.println(stepsMike);
		System.out.println(heartRateMike);
		System.out.println(distanceMike);
		System.out.println("and the distance is equal to ");
		distanceMike.changeDistanceUnit(DistanceUnit.MILES);
		System.out.print(distanceMike.getValue());
		System.out.println(" "+distanceMike.getDistanceUnit());
		System.out.println("_____________________");
		System.out.println("Eddy's statistics: ");
		System.out.println("the number of steps is " + stepsEddy.getValue() + " steps.");
		System.out.println("the heart rate is " + heartRateEddy.getValue() + " BPM.");
		System.out.println(distanceEddy);
		distanceEddy.changeDistanceUnit(DistanceUnit.MILES);
		System.out.print("and the distance in miles is equal to " + distanceEddy.getValue(DistanceUnit.MILES));
		System.out.println(" "+distanceEddy.getDistanceUnit());
		System.out.println("_____________________");
		System.out.println("Zahra's statistics: ");
		System.out.println(distanceZahra);
		System.out.println("and the distance is equal to ");
		distanceZahra.changeDistanceUnit(DistanceUnit.KILOMETRES);
		System.out.print(distanceZahra.getValue());
		System.out.println(" "+distanceZahra.getDistanceUnit());
		
	}
	
}
