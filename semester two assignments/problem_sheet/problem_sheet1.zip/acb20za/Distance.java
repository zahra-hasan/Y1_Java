/** 
* Distance.java
* 
* Copyright (c) University of Sheffield, 2021
* 
* @version 1.3 11/01/2021
* 
* @author Maria-Cruz Villa-Uriol
* @author Ben Clegg
*/

package uk.ac.sheffield.com1003.problemsheet1;

public class Distance {
	
	// Enum of distance units
	public enum DistanceUnit {
		KILOMETRES,
		MILES
	}
	
	// Constants
	private static final double KMS_PER_MILE = 1.609; 
	private static final double MILES_PER_KM = 0.621; 
	
	// Instance variables
	private double value;
	private DistanceUnit distanceUnit;
	//constant to store different distance values as requested in getValue(DistanceUnit unit) without changing the current value
	private double changedValue;
	
	
	// Constructors 
	public Distance(double value) {
		this.value = value;
		// Default unit is km
		this.distanceUnit = DistanceUnit.KILOMETRES;
	}

	public Distance(double value, DistanceUnit distanceUnit) {
		this.value = value;
		this.distanceUnit = distanceUnit;
	}
	
	public double getValue() {
		return value;
	}
	
	public double getValue(DistanceUnit unit) {
		
		//check if the requested unit is different than the current unit
		if (!(distanceUnit.equals(unit))) {
			//update the distance value accordingly
			if (distanceUnit.equals(DistanceUnit.KILOMETRES)){
				changedValue = convertToMiles(value);
				}
			
			if (distanceUnit.equals(DistanceUnit.MILES)){
				changedValue = convertToKilometres(value);
				} 
			}		 
		//if not different, return the same value
		if (distanceUnit.equals(unit)) {
			changedValue = value;
			}
		return changedValue;
	}
	
	public void setValue(double newValue) {
		this.value = newValue;
	}
	
	public DistanceUnit getDistanceUnit() {
		return distanceUnit;
	}
	
	public void changeDistanceUnit(DistanceUnit newDistanceUnit) {
		
		//check if the requested unit is different than the current unit
		if (!(newDistanceUnit.equals(distanceUnit))) {
			this.distanceUnit  = newDistanceUnit;
			//update the distance value accordingly 
			if (newDistanceUnit.equals(DistanceUnit.KILOMETRES)) {
				value = convertToKilometres(value);
				}
			
			if  (newDistanceUnit.equals(DistanceUnit.MILES)) {
				value = convertToMiles(value);
				}
			}
	}
	
	public static double convertToMiles(double kilometres) {
	    kilometres = kilometres*MILES_PER_KM;
		return kilometres;
	}
	
	public static double convertToKilometres(double miles) {
	    miles = miles*KMS_PER_MILE;
		return miles;
	}
	
	public String toString() {
	    String distanceObject = "The distance is "+ value + " " +distanceUnit+".";
		return distanceObject;
	}
	
	
}
