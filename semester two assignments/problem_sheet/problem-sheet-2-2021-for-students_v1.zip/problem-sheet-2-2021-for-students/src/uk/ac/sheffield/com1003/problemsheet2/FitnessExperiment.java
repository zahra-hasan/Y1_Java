/** 
* FitnessExperiment.java
* 
* Copyright (c) University of Sheffield, 2021
* 
* @version 1.3 11/01/2021
* 
* @author Maria-Cruz Villa-Uriol
* @author Ben Clegg
*/

package uk.ac.sheffield.com1003.problemsheet2;

import java.util.ArrayList;
import java.util.Arrays;
import uk.ac.sheffield.com1003.problemsheet1.*;

public class FitnessExperiment {
	
	FitnessTracker[] fitnessTrackers;
	
	public static void main(String[] args) {
		
	}
	
	// Constructor
	public FitnessExperiment(FitnessTracker[] fitnessTrackers) {
		this.fitnessTrackers = fitnessTrackers;
	}
	
	// Methods to implement:

	/*
	// Implementation hint: Should it use the corresponding toString() methods for 
	// each of the objects stored in the fitnessTrackers array?
	public String toString() {
		// TODO Implement
	}
	
	// Method displays in console the details of this experiment which include:
	// - Summary of the measurements of each individual fitness tracker 
	//   (indicating if they are steps, distance or heart rate measurements)
	// - The total number of fitness trackers that participated in this experiment
	// - A summary of total number of steps and total distance walked in this experiment
	// Implementation hint:  Should it use the toString() method right above this method?	
	public void printExperimentDetails() {
		// TODO Implement
	}
	
	// Method should iterate through all fitness tracker step measurements and returns a double 
	// with the total step count (see Task 2) 
	// Implementation hint: The instanceof operator and casting may become handy here 	
	public int getTotalSteps() {
		// TODO Implement
	}
	
	// Method should iterate through all fitness tracker distance measurements and returns a double with the total distance  
	// Implementation hint: The instanceof operator and casting may become handy here
	public double getTotalDistance() {
		// TODO Implement
	}
	
	public FitnessTracker[] getTrackersEqualTo(FitnessTracker tracker) {
		// TODO Implement a method that finds the trackers which are equal to tracker
	}
	
	// Implementation hint: use the above getTrackersEqualTo() method 
	public void printAllEqualTrackers() {
		// TODO Implement a method which prints every duplicate tracker
	}
	*/
	
}
