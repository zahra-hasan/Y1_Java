package flatshare;
import sheffield.*;
/**
* A class to represent a flat
* @author sdn
*/
public class Flat {
	
	final int MAX_TENANTS = 20;
	
	private Person [] tenants;
	
	/**
	* Constructor
	* creates a flat with tenants identified from the parameter
	* @param listOfNames A list of names separated by commas and possibly spaces as well
	*/
	public Flat (String listOfNames) {
		//Task 1 involves writing this
    }
    
    /**
    * A method to save the list of tenants to a file one to a line using the
    * toString() method of Person to print them out
    * @param fileName the name of the file to store the tenants in
    */
    public void saveToFile(String fileName)  {
 		//Task 2 involves writing this
    }
    
	/**
	* Constructor
	* creates a flat with tenants identified from a file containing tenants details
	* one tenant to a line
	* @param file An EasyReader accessing the file
	*/
	public Flat (EasyReader file) {
 		//Task 2 involves writing this too
 		//Task 6 involves improving this
    }
    
    /**
    * Adds another tenant to the end of the existing list of tenants
    * @param newOne The name of the new tenant
    */
    public void addTenant(String newOne)  {
  		//Task 3 involves writing this
    }
    
    /**
    * Removes a tenant from the list of tenants
    * The order of the remaining tenants stays the same
    * @param remove The name of the tenant to remove
    */
    public void removeTenant(String remove)  {
 		//Task 3 involves writing this too
   }
   
   /**
   * Records the fact that someone has bought something useful for the flat
   * Everyone contributes the same amount to the purchase but the person
   * who did the shopping gets the money they paid as a credit unless
   * they don't actually live there
   * Something useful is something that appears in the Requirements
   * @param shopper the name of the person who did the shopping
   * @param item what was bought
   * @param price what was paid for it
   */
   public void purchase(String shopper, String item, double price) {
 		//Task 4 involves writing this and
  		//Task 5 involves changing it
  }
   	   
   /**
   * A standard toString method.  Lists the tenants in order using the toString
   * method of the Person class to print them out
   * @return A String listing the tenants
   */
   public String toString() {
   	   if  (  tenants == null  ) return "The flat is empty";
   	   String result = "The tenants are : ";
   	   for (Person t : tenants) result += ", "+t.toString();
   	   result = result.replace(": ,",":");
   	   return result;
   }
   
}
     	 	 
     	 
     	 
	
	